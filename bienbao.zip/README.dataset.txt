# bien-bao-giao-thong-viet-nam zalo > 2023-02-05 1:15am
https://universe.roboflow.com/classification/bien-bao-giao-thong-viet-nam-zalo

Provided by a Roboflow user
License: CC BY 4.0

